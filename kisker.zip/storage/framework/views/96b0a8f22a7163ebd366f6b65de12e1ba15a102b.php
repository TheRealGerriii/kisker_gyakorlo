
<?php $__env->startSection("content"); ?>
<div class="container">
    <form action="/store-pet" method="post">
        <?php echo csrf_field(); ?>
        <p>
            <label for=""> Név: </label>
            <input class="form-control" type="text" name="pet">
            <br>
        </p>
        <p>
            <label for=""> Fajta: </label>
            <input class="form-control" type="text" name="type">
            <br>
        </p>
        <p>
            <label for=""> Ár: </label>
            <input class="form-control" type="text" name="price">
        </p>
        <p>
            <button class="btn btn-outline-primary" type="submit">Küldés</button>
        </p>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\diak\Desktop\dev\Backend\Laravel\kisker\resources\views//new_pet.blade.php ENDPATH**/ ?>