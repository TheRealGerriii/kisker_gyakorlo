
<?php $__env->startSection("content"); ?>
<div class="container">
    <form action="/update" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" value="<?php echo e($pet->id); ?>" name="pet_id">
        <p>
            <label for=""> Név: </label>
            <input class="form-control" type="text" name="pet" value="<?php echo e($pet->pet); ?>">
            <br>
        </p>
        <p>
            <label for=""> Email: </label>
            <input class="form-control" type="text" name="type" value="<?php echo e($pet->type); ?>">
            <br>
        </p>
        <p>
            <label for=""> Telefon: </label>
            <input class="form-control" type="text" name="price" value="<?php echo e($pet->price); ?>">
        </p>
        <p>
            <button class="btn btn-outline-primary" type="submit">Frissítés</button>
        </p>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\diak\Desktop\dev\Backend\Laravel\kisker\resources\views/modify.blade.php ENDPATH**/ ?>