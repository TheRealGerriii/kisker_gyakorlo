
<?php $__env->startSection("content"); ?>

<div class="container">
  <div class="mt-3 col-lg-3 offset-lg-4">
    <form action="search-pet">
      <select name="type" id="" class="form-select">
        <option selected>Válasszon egy opciót</option>
        <option value="kutya">kutya</option>
        <option value="macska">macska</option>
        <option value="hal">hal</option>
      </select>
      <button class=" btn btn-outline-info mt-2" type="submit">Keresés</button>
  </div>
  </form>
  <div class="mt-2">
    <a class="btn btn-outline-danger" href="/register">Regisztráció</a>
    <a class="btn btn-outline-danger" href="/login">Bejelentkezés</a>
    <a class="btn btn-outline-danger" href="/logout">Kijelentkezés</a>
    <a class="btn btn-outline-primary" href="/new">Új felvétele</a>
    <a class="btn btn-outline-primary" href="/">Főoldal</a>
  </div>
    <table class="table">
        <thead>
          <tr>
            <th>Id</th>
            <th>Név</th>
            <th>Típus</th>
            <th>Ár</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
               <td><?php echo e($pet->id); ?></td>
               <td><?php echo e($pet->pet); ?></td>
               <td><?php echo e($pet->type); ?></td>
               <td><?php echo e($pet->price); ?></td>
               <td>
                    <a class="btn btn-info" href="/update/<?php echo e($pet->id); ?>">Szerkesztés</a>
                    <a class="btn btn-outline-primary" href="/delete/<?php echo e($pet->id); ?>">Törlés</a>
                </td>
             </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\diak\Desktop\dev\Backend\Laravel\kisker\resources\views//list_pets.blade.php ENDPATH**/ ?>